import React from 'react'

const MyJobs = () => {
  return (
    <div>MyJobs</div>
  )
}

export default MyJobs