import React from 'react'

const PostJob = () => {
  return (
    <div>PostJob</div>
  )
}

export default PostJob