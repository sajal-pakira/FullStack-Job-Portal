import React from 'react'

const Job = () => {
  return (
    <div>Job</div>
  )
}

export default Job